package com.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;

import com.model.Tourist;

public class TouristControllerImplements implements TouristController {

    private Connection conn;

    public TouristControllerImplements() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartcity", "root", "");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean addTourist(Tourist t) {
        String sql = "INSERT INTO touristtable(Username, Email, Password, PhoneNumber, Address) VALUES(?, ?, ?, ?, ?)";
        try {
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, t.getUsername());
            pstm.setString(2, t.getEmail());
            String hashPwd = DigestUtils.shaHex(t.getPassword().getBytes());
            pstm.setString(3, hashPwd);
            pstm.setString(4, t.getPhoneNumber());
            pstm.setString(5, t.getAddress());

            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
	public boolean touristLogin(String email, String pwd) {
		boolean answer = false;
		String hashPassword = DigestUtils.shaHex(pwd.getBytes());
		String sql = "SELECT * FROM touristtable where Email=? and Password=?";
		try {
			PreparedStatement pstm = conn.prepareStatement(sql);
			pstm.setString(1, email);
			 pstm.setString(2, hashPassword);
	            ResultSet rs = pstm.executeQuery();

	            if (rs.next()) {
	                answer = true;
	            } else {
	                answer = false;
	            }
	        } catch (SQLException e) {
	            // Handle or log the exception
	            e.printStackTrace();
	       
		}
		return answer;
	}


    
    @Override
    public List<Tourist> getAllTourists() {
        List<Tourist> touristList = new ArrayList<>();
        String sql = "SELECT * FROM touristtable";
        try (PreparedStatement pstm = conn.prepareStatement(sql);
             ResultSet rs = pstm.executeQuery()) {
            while (rs.next()) {
                Tourist t = new Tourist();
                t.setId(rs.getInt("Id"));
                t.setUsername(rs.getString("Username"));
                t.setEmail(rs.getString("Email"));
                t.setPassword(rs.getString("Password"));
                t.setPhoneNumber(rs.getString("PhoneNumber"));
                t.setAddress(rs.getString("Address"));
                touristList.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (touristList.isEmpty()) {
            System.out.println("No tourists found in the database.");
        } else {
            System.out.println("Tourist list retrieved successfully:");
            for (Tourist t : touristList) {
                System.out.println(t); // Assuming Tourist class has overridden toString() method
            }
        }
        return touristList;
    }
    @Override
    public List<Tourist> getTouristByID(int id) {
        List<Tourist> touristList = new ArrayList<>();
        String sql = "SELECT * FROM touristtable WHERE Id=?";
        
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, id);
            try (ResultSet rs = pstm.executeQuery()) {
                while (rs.next()) {
                    Tourist t = new Tourist();
                    t.setId(rs.getInt("Id"));
                    t.setUsername(rs.getString("Username"));
                    t.setEmail(rs.getString("Email"));
                    t.setPassword(rs.getString("Password"));
                    t.setPhoneNumber(rs.getString("PhoneNumber"));
                    t.setAddress(rs.getString("Address"));
                    touristList.add(t);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return touristList;
    }
	
	 
    @Override
    public Tourist getTouristByEmail(String email) {
        Tourist tourist = null;
        String sql = "SELECT * FROM touristtable WHERE Email = ?";

        try {
            // Using the existing connection
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, email);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                tourist = new Tourist();
                tourist.setId(rs.getInt("Id"));
                tourist.setUsername(rs.getString("Username"));
                tourist.setEmail(rs.getString("Email"));
                tourist.setPassword(rs.getString("Password"));
                tourist.setPhoneNumber(rs.getString("PhoneNumber"));
                tourist.setAddress(rs.getString("Address"));
            }
            // Close the ResultSet and PreparedStatement
            rs.close();
            pstm.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tourist;
    }
    
    @Override
    public boolean editTourist(Tourist t) {
        String sql = "UPDATE touristtable SET Username=?, Email=?, Password=?, PhoneNumber=?, Address=? WHERE Id=?";
        
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setString(1, t.getUsername());
            pstm.setString(2, t.getEmail());
            pstm.setString(3, t.getPassword());
            pstm.setString(4, t.getPhoneNumber());
            pstm.setString(5, t.getAddress());
            pstm.setInt(6, t.getId());
            
            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean deleteTourist(int id) {
        String sql = "DELETE FROM touristtable WHERE Id=?";
        
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, id);
            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void close() {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                // Handle or log the exception
                e.printStackTrace();
            }
        }
    }

	@Override
	public boolean updatePassword(String email, String pwd) {
		 String sql = "UPDATE touristtable SET Password = ? WHERE Email = ?";

		    try {
		        PreparedStatement pstm = conn.prepareStatement(sql);
		        pstm.setString(1, pwd); // Set the new password
		        pstm.setString(2, email); // Set the email to identify the student
		        int rowsAffected = pstm.executeUpdate();
		        return rowsAffected > 0;
		    } catch (SQLException e) {
		        e.printStackTrace();
		        System.out.println("Error in updating password");
		    }
		    return false;
		}

	@Override
	public int registeredTouristsCount() {
		String sql = "SELECT COUNT(*) AS total FROM touristtable";
	    int count = 0;
	    
	    try {
	         PreparedStatement pstm = conn.prepareStatement(sql);
	         ResultSet rs = pstm.executeQuery(); 
	         
	        if (rs.next()) {
	            count = rs.getInt("total");
	        }
	        
	        rs.close(); // Close the ResultSet
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("Error in getting total places");
	    }
	    
	    return count;
	}
	
	
	
}
