package com.controller;

public class AdminControllerImplements implements AdminController {
    private static String StoredUsername = "admin";
    private static String StoredPassword = "admin@123";

    @Override
    public boolean AdminLogin(String un, String pwd) {
        return un.equals(StoredUsername) && pwd.equals(StoredPassword);
    }
}