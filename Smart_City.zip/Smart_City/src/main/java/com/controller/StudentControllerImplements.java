package com.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;

import com.model.Student;

public class StudentControllerImplements implements StudentController {
    Connection conn = null;

    public StudentControllerImplements() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartcity", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize the database connector", e);
        }
    }

    @Override
    public boolean addStudent(Student s) {
        String sql = "INSERT INTO studenttable(Username, Email, Password, PhoneNumber, Address) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, s.getUsername());
            pstm.setString(2, s.getEmail());
            String hashPwd = DigestUtils.shaHex(s.getPassword().getBytes());
            pstm.setString(3, hashPwd);
            pstm.setString(4, s.getPhoneNumber());
            pstm.setString(5, s.getAddress());

            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
   
    
    @Override
    public boolean studentLogin(String email, String pwd) {
        boolean answer = false;
        String hashPassword = DigestUtils.shaHex(pwd.getBytes());
        String sql = "SELECT * FROM studenttable WHERE Email=? AND Password=?";
        try {
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, email);
            pstm.setString(2, hashPassword);
            ResultSet rs = pstm.executeQuery();

            if (rs.next()) {
                answer = true;
            } else {
                answer = false;
            }
        } catch (SQLException e) {
            // Handle or log the exception
            e.printStackTrace();
        }
        return answer;
    }
   

    @Override
    public List<Student> getAllStudents() {
        List<Student> studentList = new ArrayList<>();
        String sql = "SELECT * FROM studenttable";
        
        try {
			Statement stm = conn.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			
			while(rs.next()) {
				Student s = new Student();
				s.setId(rs.getInt("Id"));
				s.setUsername(rs.getString("Username"));
				s.setEmail(rs.getString("Email"));
				s.setPassword(rs.getString("Password"));
				s.setPhoneNumber(rs.getString("Phonenumber"));
				s.setAddress(rs.getString("Address"));
				
				studentList.add(s);
			}
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to retrieve student list", e);
        }
        if (studentList.isEmpty()) {
    		Student defaultStudent = new Student();
    		defaultStudent.setId(0);
    		defaultStudent.setUsername("No students found");
    		defaultStudent.setEmail("");
    		defaultStudent.setPassword("");
    		defaultStudent.setPhoneNumber("");
    		defaultStudent.setAddress("");
    		studentList.add(defaultStudent);
    		}
        return studentList;
    }

	private Connection getConnection() throws SQLException {
	    // Your existing code to establish a database connection (replace with your actual implementation)
	    try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartcity", "root", "");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			throw new RuntimeException("Failed to establish database connection", e);
		}

	    return conn;
	}
	 

	@Override
	public List<Student> getStudentByID(int id) {
		List<Student> studentList = new ArrayList<>();
		String sql = "Select * from studenttable where Id= ?";
		
		try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, id);
            try (ResultSet rs = pstm.executeQuery()) {
                while (rs.next()) {
                    Student s = new Student();
                    s.setId(rs.getInt("Id"));
                    s.setUsername(rs.getString("Username"));
                    s.setEmail(rs.getString("Email"));
                    s.setPassword(rs.getString("Password"));
                    s.setPhoneNumber(rs.getString("PhoneNumber"));
                    s.setAddress(rs.getString("Address"));
                    studentList.add(s);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Unable to retrive studentList by ID.");
        }
        return studentList;
    }
	
	@Override
    public Student getStudentByEmail(String email) {
        Student student = null;
        String sql = "SELECT * FROM studenttable WHERE Email = ?";

        try (Connection conn = getConnection()) {
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, email);
            ResultSet rs = pstm.executeQuery();

            if (rs.next()) {
                student = new Student();
                student.setId(rs.getInt("Id"));
                student.setUsername(rs.getString("Username"));
                student.setEmail(rs.getString("Email"));
                student.setPassword(rs.getString("Password"));
                student.setPhoneNumber(rs.getString("PhoneNumber"));
                student.setAddress(rs.getString("Address"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return student;
    }

	@Override
	public boolean editStudent(Student s) {
		String sql = "update studenttable set Username=?, Email=?, PhoneNumber=?, Address=? where Id=?";

		try {
			PreparedStatement pstm = conn.prepareStatement(sql);
			System.out.println("Updated Students: " +pstm);
			pstm.setString(1, s.getUsername());
			pstm.setString(2, s.getEmail());
			pstm.setString(3, s.getPhoneNumber());
			pstm.setString(4, s.getAddress());
			pstm.setInt(5, s.getId());
			
			int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Error in editing student");
		}
		return false;
	}

	@Override
	public boolean deleteStudent(int id) {
        String sql = "DELETE FROM studenttable WHERE Id=?";
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, id);
            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle or log the exception appropriately
            return false;
        }
    }
	
	@SuppressWarnings("unused")
	private String[] getEmailCredentialsForStudent(String email) {
	    String[] emailCredentials = new String[2]; // Array to store email and password
	    String sql = "SELECT Email, Password FROM studenttable WHERE Email = ?";
	    try (Connection conn = getConnection();
	         PreparedStatement pstm = conn.prepareStatement(sql)) {
	        pstm.setString(1, email);
	        ResultSet rs = pstm.executeQuery();
	        if (rs.next()) {
	            emailCredentials[0] = rs.getString("Email");
	            emailCredentials[1] = rs.getString("Password");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        // Handle or log the exception appropriately
	    }
	    return emailCredentials;
	}

	
	public void printSQLException(SQLException ex) {
    	for (Throwable e:ex) {
    		if(e instanceof SQLException) {
    			e.printStackTrace(System.err);
    			System.err.println("SQLState: " +((SQLException) e).getSQLState());
    			System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
    			System.err.println("Message: " + e.getMessage());
    			Throwable t =ex.getCause();
    			while(t!=null) {
    				System.out.println("Cause: " +t);
    				t = t.getCause();
    			}
    		}
    	}
	}

	@Override
	public boolean updatePassword(String email, String pwd) {
	    String sql = "UPDATE studenttable SET Password = ? WHERE Email = ?";

	    try {
	        PreparedStatement pstm = conn.prepareStatement(sql);
	        pstm.setString(1, pwd); // Set the new password
	        pstm.setString(2, email); // Set the email to identify the student
	        int rowsAffected = pstm.executeUpdate();
	        return rowsAffected > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("Error in updating password");
	    }
	    return false;
	}

	@Override
	public int registeredStudentsCount() {
		String sql = "SELECT COUNT(*) AS total FROM studenttable";
	    int count = 0;
	    
	    try {
	         PreparedStatement pstm = conn.prepareStatement(sql);
	         ResultSet rs = pstm.executeQuery(); 
	         
	        if (rs.next()) {
	            count = rs.getInt("total");
	        }
	        
	        rs.close(); // Close the ResultSet
	    } catch (SQLException e) {
	        e.printStackTrace();
	        System.out.println("Error in getting total places");
	    }
	    
	    return count;
	}

		

	

	
}
