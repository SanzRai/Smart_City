package com.controller;

import java.util.List;

import com.model.Student;


public interface StudentController {
	
	public boolean addStudent(Student s);
	
	public boolean studentLogin(String email, String pwd);
	
	public List<Student> getAllStudents();
	
	public List<Student> getStudentByID(int id);
	
	public Student getStudentByEmail(String email);
			
	public boolean editStudent(Student s);
	
	public boolean deleteStudent(int id);
	
	public boolean updatePassword(String email, String pwd);
	
	public int registeredStudentsCount();

}
