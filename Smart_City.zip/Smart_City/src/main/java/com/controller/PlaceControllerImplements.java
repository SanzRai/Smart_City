package com.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.Place;

public class PlaceControllerImplements implements PlaceController{
	Connection conn = null;
	
	public PlaceControllerImplements() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smartcity", "root","");
		} catch (ClassNotFoundException| SQLException e) {
			
		}
	}

	@Override
	public boolean addPlace(Place place) {
		String sql = "INSERT INTO placestable (State, City, Category, Name, ImagePath, FullAddress, Description) VALUES (?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstm = conn.prepareStatement(sql);
			pstm.setString(1, place.getState());
			pstm.setString(2, place.getCity());
			pstm.setString(3, place.getCategory());
			pstm.setString(4, place.getName());
			pstm.setString(5, place.getImagePath());
			pstm.setString(6, place.getFullAddress());
			pstm.setString(7, place.getDescription());
			
			int rowsAffected = pstm.executeUpdate();
			return rowsAffected>0;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
	}
		public void close() {
			try {
				if(conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		@Override
		public List<Place> getAllData() {
			List<Place> placeList = new ArrayList<>();
			String sql = "Select * from placestable";
			
			try {
				Statement stm = conn.createStatement();
				ResultSet rs = stm.executeQuery(sql);
				
				while(rs.next()) {
					Place place = new Place();
					place.setId(rs.getInt("Id"));
					place.setState(rs.getString("State"));
					place.setCity(rs.getString("City"));
					place.setCategory(rs.getString("Category"));
					place.setName(rs.getString("Name"));
					place.setImagePath(rs.getString("ImagePath"));
					place.setFullAddress(rs.getString("FullAddress"));
					place.setDescription(rs.getString("Description"));
					
					placeList.add(place);
				}
			} catch (SQLException e) {
				e.printStackTrace();
				
			}
			
			return placeList;
		}
		
		
		@Override
	    public List<Place> getPlaceByID(int id) {
			List<Place> placeList = new ArrayList<>();
		    String sql = "SELECT * FROM placestable WHERE Id = ?";
		    try {
		        PreparedStatement pstm = conn.prepareStatement(sql);
		        pstm.setInt(1, id);
		        ResultSet rs = pstm.executeQuery();

		        while (rs.next()) {
		            Place place = new Place();
		            place.setId(rs.getInt("Id"));
		            place.setState(rs.getString("State"));
		            place.setCity(rs.getString("City"));
		            place.setCategory(rs.getString("Category"));
		            place.setName(rs.getString("Name"));
		            place.setImagePath(rs.getString("ImagePath"));
		            place.setFullAddress(rs.getString("FullAddress"));
		            place.setDescription(rs.getString("Description"));

		            placeList.add(place);
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }

	        return placeList;
	    }

	    @Override
	    public boolean deletePlace(int id) {
	        String sql = "DELETE FROM placestable WHERE Id= ?";
	        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
	            pstm.setInt(1, id);
	            int rowsAffected = pstm.executeUpdate();
	            return rowsAffected > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	    @Override
	    public boolean editPlace(Place place) {
	        String sql = "UPDATE placestable SET State=?, City=?, Category=?, Name=?, ImagePath=?, FullAddress=?, Description=? WHERE id=?";
	        try {
	            PreparedStatement pstm = conn.prepareStatement(sql);
	            pstm.setString(1, place.getState());
	            pstm.setString(2, place.getCity());
	            pstm.setString(3, place.getCategory());
	            pstm.setString(4, place.getName());
	            pstm.setString(5, place.getImagePath());
	            pstm.setString(6, place.getFullAddress());
	            pstm.setString(7, place.getDescription());
	            pstm.setInt(8, place.getId());

	            int rowsAffected = pstm.executeUpdate();
	            return rowsAffected > 0;

	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

		@Override
		public List<Place> getPlaceByCategory(String category) {
			List<Place> placeList = new ArrayList<>();
			String sql = "SELECT * FROM placestable WHERE Category=?";
			
			try {
				PreparedStatement pstm = conn.prepareStatement(sql);
				pstm.setString(1, category);
				ResultSet rs = pstm.executeQuery();
				
				while(rs.next()) {
					Place place = new Place();
					place.setId(rs.getInt("Id"));
					place.setState(rs.getString("State"));
					place.setCity(rs.getString("City"));
					place.setCategory(rs.getString("Category"));
					place.setName(rs.getString("Name"));
					place.setImagePath(rs.getString("ImagePath"));
					place.setFullAddress(rs.getString("FullAddress"));
					place.setDescription(rs.getString("Description"));
					
					placeList.add(place);
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Could not retrieve placeList by Category");
			}
			return placeList;
		}

		@Override
		public List<Place> getPlaceByAddress(String City, String Category) {
			List<Place> placeList = new ArrayList<>();
			String sql = "SELECT * FROM placestable WHERE City=? AND Category=?";
			
			try {
				PreparedStatement pstm = conn.prepareStatement(sql);
				pstm.setString(1, City);
				pstm.setString(2, Category);
				ResultSet rs = pstm.executeQuery();
				
				while(rs.next()) {
					Place place = new Place();
					place.setId(rs.getInt("Id"));
					place.setState(rs.getString("State"));
					place.setCity(rs.getString("City"));
					place.setCategory(rs.getString("Category"));
					place.setName(rs.getString("Name"));
					place.setImagePath(rs.getString("ImagePath"));
					place.setFullAddress(rs.getString("FullAddress"));
					place.setDescription(rs.getString("Description"));
					
					placeList.add(place);
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Could not retrieve placeList by Category");
			}
			return placeList;
	
		}

		@Override
		public int addedPlacesCount() {
		    String sql = "SELECT COUNT(*) AS total FROM placestable";
		    int count = 0;
		    
		    try {
		         PreparedStatement pstm = conn.prepareStatement(sql);
		         ResultSet rs = pstm.executeQuery(); 
		         
		        if (rs.next()) {
		            count = rs.getInt("total");
		        }
		        
		        rs.close(); // Close the ResultSet
		    } catch (SQLException e) {
		        e.printStackTrace();
		        System.out.println("Error in getting total places");
		    }
		    
		    return count;
		}


}

