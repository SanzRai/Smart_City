package com.controller;

import java.util.List;

import com.model.Tourist;

public interface TouristController {
		
	public boolean addTourist(Tourist t);
	
	public boolean touristLogin(String email, String pwd);
	
	public List<Tourist> getAllTourists();
	
	public List<Tourist> getTouristByID(int id);
	
	public Tourist getTouristByEmail(String email);
			
	public boolean editTourist(Tourist t);
	
	public boolean deleteTourist(int id);
	
	public boolean updatePassword(String email, String pwd);

	public int registeredTouristsCount();
}
