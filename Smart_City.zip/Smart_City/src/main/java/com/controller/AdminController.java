package com.controller;

public interface AdminController {
	 boolean AdminLogin(String un, String pwd);

}

