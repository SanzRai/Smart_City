package com.controller;

import java.util.List;

import com.model.Place;

public interface PlaceController {
	public boolean addPlace (Place place);
	
	public List<Place>getAllData();
	
	public boolean deletePlace(int Id);
	
	public List<Place>getPlaceByID(int Id);
	
	public boolean editPlace(Place place);
	
	public List<Place> getPlaceByCategory(String category);
	
	public List<Place> getPlaceByAddress(String City, String Category);
	
	public int addedPlacesCount();

}
