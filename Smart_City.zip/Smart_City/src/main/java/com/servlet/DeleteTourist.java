package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.TouristController;
import com.controller.TouristControllerImplements;

/**
 * Servlet implementation class DeleteTourist
 */
@WebServlet("/DeleteTourist")
public class DeleteTourist extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int Id = Integer.valueOf(request.getParameter("Id"));
		
		TouristController tc = new TouristControllerImplements();
		 boolean deleted = tc.deleteTourist(Id);
	        if (deleted) {
	            // Student deleted successfully
	            request.setAttribute("successMessage", "Tourist deleted successfully");
	        } else {
	            // Failed to delete student
	            request.setAttribute("errorMessage", "Failed to delete tourist");
	        }
	        request.setAttribute("touristList", tc.getAllTourists());
	        request.getRequestDispatcher("TouristTable.jsp").forward(request, response);
		
		
	}

}
