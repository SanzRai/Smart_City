package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.PlaceController;
import com.controller.PlaceControllerImplements;

/**
 * Servlet implementation class DeletePlace
 */
@WebServlet("/DeletePlace")
public class DeletePlace extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  int Id = Integer.parseInt(request.getParameter("Id"));
		    System.out.println("ID: " + Id);
		    
		    PlaceController pc = new PlaceControllerImplements();
		    boolean deleted = pc.deletePlace(Id);
	        if (deleted) {
	            // Student deleted successfully
	            request.setAttribute("successMessage", "Place deleted successfully");
	        } else {
	            // Failed to delete student
	            request.setAttribute("errorMessage", "Failed to delete place data");
	        }
	        request.setAttribute("placeList", pc.getAllData());
	        request.getRequestDispatcher("PlaceTable.jsp").forward(request, response);
	    }

}
