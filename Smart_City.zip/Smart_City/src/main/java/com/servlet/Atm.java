package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.PlaceController;
import com.controller.PlaceControllerImplements;
import com.model.Place;

/**
 * Servlet implementation class Atm
 */
@WebServlet("/Atm")
public class Atm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PlaceController pc = new PlaceControllerImplements();

        // Fetch all places
        List<Place> placeList = pc.getAllData();
        request.setAttribute("placeList", placeList);

        // Fetch ATM places
        List<Place> atmPlaces = pc.getPlaceByCategory("ATM");
        request.setAttribute("atmPlaces", atmPlaces);

        request.getRequestDispatcher("Atm.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
