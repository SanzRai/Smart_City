package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.model.Student;

@WebServlet("/EditStudent")
public class EditStudent extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("EditStudent.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int Id = Integer.valueOf(request.getParameter("Id"));
        System.out.println("ID: " + Id);

        StudentController sc = new StudentControllerImplements();
        List<Student> studentList = sc.getStudentByID(Id);

        request.setAttribute("studentList", studentList);
        request.getRequestDispatcher("EditStudent.jsp").forward(request, response);
    }
}
