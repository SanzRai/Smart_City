package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.PlaceController;
import com.controller.PlaceControllerImplements;
import com.model.Place;

/**
 * Servlet implementation class TouristHome
 */
@WebServlet("/TouristHome")
public class TouristHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PlaceController pc = new PlaceControllerImplements();

    // Fetch all places
    List<Place> placeList = pc.getAllData();
    request.setAttribute("placeList", placeList);

    // Fetch places for tourist attractions
    List<Place> attractionPlaces = pc.getPlaceByCategory("Tourist Attractions");
    request.setAttribute("attractionPlaces", attractionPlaces);

    // Fetch places for ATMs
    List<Place> atmPlaces = pc.getPlaceByCategory("ATMs");
    request.setAttribute("atmPlaces", atmPlaces);

    // Fetch places for hospitals
    List<Place> hospitalPlaces = pc.getPlaceByCategory("Hospitals");
    request.setAttribute("hospitalPlaces", hospitalPlaces);

    // Fetch places for hotels
    List<Place> hotelPlaces = pc.getPlaceByCategory("Hotels");
    request.setAttribute("hotelPlaces", hotelPlaces);

    request.getRequestDispatcher("TouristHome.jsp").forward(request, response);
}

		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
