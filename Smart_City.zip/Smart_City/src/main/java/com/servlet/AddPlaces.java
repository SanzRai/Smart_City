package com.servlet;

import com.model.Place;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.PlaceController;
import com.controller.PlaceControllerImplements;


@WebServlet("/AddPlaces")
public class AddPlaces extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("AddPlaces.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String state = request.getParameter("state");
        String city = request.getParameter("city");
        String category = request.getParameter("category");
        String name = request.getParameter("name");
        String image = request.getParameter("image");
        String fullAddress = request.getParameter("fullAddress");
        String description = request.getParameter("description");
        
        try {
            // Validate inputs before creating Place object
            if (isValid(state, city, category, name, fullAddress, description)) {
            
                Place place = new Place();
                place.setState(state);
                place.setCity(city);
                place.setCategory(category);
                place.setName(name);
                place.setImagePath(image);
                place.setFullAddress(fullAddress);
                place.setDescription(description);

                PlaceController pc = new PlaceControllerImplements();
                boolean isAdded = pc.addPlace(place);

                if (isAdded) {
                    request.setAttribute("successMessage", "Data Added Successfully");
                    request.setAttribute("showAddMoreOption", true); // Add attribute for "Add More" prompt
                    request.getRequestDispatcher("PlaceTable.jsp").forward(request, response);
                } else {
                    request.setAttribute("error", "There seems to be a problem in adding the data.");
                    request.getRequestDispatcher("AddPlaces.jsp").forward(request, response);
                }
            } else {
                // Display validation error message
                request.setAttribute("error", "All fields are required.");
                request.getRequestDispatcher("AddPlaces.jsp").forward(request, response);
            }
        } catch (Exception e) {
            System.err.println("Error during adding data: " + e.getMessage());
            e.printStackTrace();
//            request.setAttribute("error", "An unexpected error occurred. Please try again later!");
            request.getRequestDispatcher("AddPlaces.jsp").forward(request, response);
        }
    }
    // Helper method for input validation
    private boolean isValid(String... fields) {
        for (String field : fields) {
            if (field == null || field.isEmpty() && "category".equals(fields)) {
                return false;
            }
        }
        return true;
    }
}