package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;

import com.model.Student;
import com.model.Tourist;
import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.controller.TouristController;
import com.controller.TouristControllerImplements;


@WebServlet("/UserSignup")
public class UserSignup extends HttpServlet {
    
    
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("UserSignup.jsp").forward(request, response);
	}
		
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String role = request.getParameter("role");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        
        String passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        if (!password.matches(passwordRegex)) {
            request.setAttribute("error", "Password must contain at least 8 characters, including uppercase letters, lowercase letters, numbers, and special characters.");
            request.getRequestDispatcher("UserSignup.jsp").forward(request, response);
            return;
        }
        
        if (password == null || !password.equals(confirmPassword)) {
            // Handle password mismatch error
            request.setAttribute("error", "Passwords do not match!");
            request.getRequestDispatcher("UserSignup.jsp").forward(request, response);
            return;
        }
        String hashPassword = DigestUtils.shaHex(password.getBytes());
        try {
        if ("student".equalsIgnoreCase(role)) {
            Student student = new Student();
            student.setUsername(username);
            student.setEmail(email);
            student.setPhoneNumber(phone);
            student.setAddress(address);
            student.setPassword(hashPassword);

            // Add student to database
            StudentController sc = new StudentControllerImplements();
            boolean success = sc.addStudent(student);
            if (success) {
            	request.setAttribute("success", "Student account has been created! Please sign in.");
                request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
            	 
            } else {
            	request.setAttribute("error", "An error occurred while creating your student account. Please try again.");
                request.getRequestDispatcher("UserSignup.jsp").forward(request, response);
            }
            
            
        } else if ("tourist".equalsIgnoreCase(role)) {
            Tourist tourist = new Tourist();
            tourist.setUsername(username);
            tourist.setEmail(email);
            tourist.setPhoneNumber(phone);
            tourist.setAddress(address);
            tourist.setPassword(hashPassword);

            // Add tourist to database
            TouristController tc = new TouristControllerImplements();
            boolean success = tc.addTourist(tourist);
            if (success) {
            	request.setAttribute("success", "Tourist account has been created! Please sign in.");
                request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
                return;
            } else {
            	request.setAttribute("error", "An error occurred while creating your tourist account. Please try again.");
                request.getRequestDispatcher("UserSignup.jsp").forward(request, response);
                return;
            }
            
        }
	        	
        }catch(Exception e) {
            System.err.println("Error during user signup: " + e.getMessage());
        	e.printStackTrace(); 
            request.setAttribute("error", "An unexpected error occurred. Please try again later!");
            request.getRequestDispatcher("UserSignup.jsp").forward(request, response);
        }
	}
}
