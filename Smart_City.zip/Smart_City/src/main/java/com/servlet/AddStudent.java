package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.model.Student;

/**
 * Servlet implementation class AddStudent
 */
@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("AddStudent.jsp").forward(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("Username");
   	    String email = request.getParameter("Email");
        String password = request.getParameter("Password");
        String phoneNumber = request.getParameter("PhoneNumber");
        String address = request.getParameter("Address");
        
        Student s = new Student();
        s.setUsername(username);
        s.setEmail(email);
        s.setPassword(password);
        s.setPhoneNumber(phoneNumber);
        s.setAddress(address);
        
        StudentController sc = new StudentControllerImplements();
        boolean added = sc.addStudent(s);
        
        if(added) {
        	List<Student> studentList = sc.getAllStudents();
        	request.setAttribute("studentList", studentList);
        	request.setAttribute("successMessage", "New student added successfully");
        	
        	
        }else {
        	request.setAttribute("errorMessage", "Failed to add new student.");
        }
        
        request.getRequestDispatcher("StudentTable.jsp").forward(request, response);
	}

}
