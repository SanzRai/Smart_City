package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.TouristController;
import com.controller.TouristControllerImplements;
import com.model.Tourist;

@WebServlet("/TouristTable")
public class TouristTable extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TouristController touristController = new TouristControllerImplements();
        
        // Retrieve all tourists
        List<Tourist> touristList = touristController.getAllTourists();
        
        // Forward the tourist list to the JSP page
        request.setAttribute("touristList", touristList);
        request.getRequestDispatcher("TouristTable.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	 String action = request.getParameter("action");
         if (action != null && action.equals("delete")) {
             int id = Integer.parseInt(request.getParameter("id"));
             TouristController tc = new TouristControllerImplements();
             boolean deleted = tc.deleteTourist(id);
             if (deleted) {
                 // Tourist deleted successfully
                 List<Tourist> touristList = tc.getAllTourists();
                 request.setAttribute("touristList", touristList);
                 request.getRequestDispatcher("TouristTable.jsp").forward(request, response);
                 request.setAttribute("successMessage", "Tourist deleted successfully");
             } else {
                 // Failed to delete tourist
                 // Handle error or display appropriate message
            	 System.out.println("Unable to delete this data.");
            	 request.setAttribute("errorMessage", "Failed to delete tourist.");
             }
         
         } else {
             // If no action is specified or action is not delete, perform edit operation
             int id = Integer.parseInt(request.getParameter("Id"));
             String username = request.getParameter("Username");
             String email = request.getParameter("Email");
             String phoneNumber = request.getParameter("PhoneNumber");
             String address = request.getParameter("Address");
            
             Tourist t = new Tourist();
             t.setId(id);
             t.setUsername(username);
             t.setEmail(email);
             t.setPhoneNumber(phoneNumber);
             t.setAddress(address);
            
             TouristController tc = new TouristControllerImplements();
             boolean edited = tc.editTourist(t);
             if(edited) {
             List<Tourist> touristList = tc.getAllTourists();
            
             request.setAttribute("touristList", touristList);
             request.setAttribute("successMessage", "Tourist data edited successfully.");
             } else {
            	 request.setAttribute("errorMessage", "Failed to edit tourist data.");
             }
         }
             request.getRequestDispatcher("TouristTable.jsp").forward(request, response);
         }
     
 }