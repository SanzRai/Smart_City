package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.PlaceController;
import com.controller.PlaceControllerImplements;
import com.model.Place;

/**
 * Servlet implementation class EditPlace
 */
@WebServlet("/EditPlace")
public class EditPlace extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("EditPlace.jsp").forward(request, response);
	}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int Id = Integer.valueOf(request.getParameter("Id"));
        System.out.println("ID: " +Id);
        
       PlaceController pc = new PlaceControllerImplements();
       List<Place> placeList = pc.getPlaceByID(Id);
       
       request.setAttribute("placeList", placeList);
        request.getRequestDispatcher("EditPlace.jsp").forward(request, response);
    }
}



