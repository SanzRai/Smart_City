package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;

import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.controller.TouristController;
import com.controller.TouristControllerImplements;

@WebServlet("/ResetPassword")
public class ResetPassword extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("ResetPassword.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword"); 
        HttpSession session = request.getSession();
        String email = (String) session.getAttribute("email");

        if (!isValidPassword(newPassword)) {
            request.setAttribute("error", "Password must contain at least 8 characters, including uppercase letters, lowercase letters, numbers, and special characters.");
            request.getRequestDispatcher("ResetPassword.jsp").forward(request, response);
            return;
        }
        if (!newPassword.equals(confirmPassword)) {
            // Handle password mismatch error
            request.setAttribute("error", "Passwords do not match!");
            request.getRequestDispatcher("ResetPassword.jsp").forward(request, response);
            return;
        }

        String hashedPassword = DigestUtils.shaHex(DigestUtils.shaHex(newPassword.getBytes())) ;
        boolean passwordUpdated = false;

        String userRole = (String) session.getAttribute("userRole");

        if (userRole != null && userRole.equals("student")) {
            StudentController sc = new StudentControllerImplements();
            passwordUpdated = sc.updatePassword(email, hashedPassword);
        } else if (userRole != null && userRole.equals("tourist")) {
            TouristController tc = new TouristControllerImplements();
            passwordUpdated = tc.updatePassword(email, hashedPassword);
        }

        if (passwordUpdated) {
            request.setAttribute("success", "Password updated successfully.");
        } else {
            request.setAttribute("error", "Failed to update password. Please try again.");
        }

        request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
    }

    private boolean isValidPassword(String newPassword) {
        return newPassword != null && newPassword.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$");
    }
}
