package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;

import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.controller.TouristController;
import com.controller.TouristControllerImplements;
import com.model.Student;

/**
 * Servlet implementation class UserLogin
 */
@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		 request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
		
	}
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    
	    String email = request.getParameter("email");
	    String password = request.getParameter("password");
	    String role = request.getParameter("role");
	    
	    String hashPwd = DigestUtils.shaHex(password.getBytes());
	    
	   
	    
	    if("Student".equalsIgnoreCase(role)) {
	        StudentControllerImplements sc = new StudentControllerImplements();
	        if(sc.studentLogin(email, hashPwd)==true) {
	        	 HttpSession session = request.getSession();
	            session.setAttribute("activeUser", email);
	            session.setAttribute("role", "Student");
	            request.getRequestDispatcher("StudentHome.jsp").forward(request, response);
	        } else {
	            request.setAttribute("error", "Email/Password is Incorrect");
	            request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
	        }
	    } else if("Tourist".equalsIgnoreCase(role)) {
	        TouristController tc = new TouristControllerImplements();
	        if(tc.touristLogin(email, hashPwd)== true) {
	        	 HttpSession session = request.getSession();
	            session.setAttribute("activeUser", email );
	            session.setAttribute("role", "Tourist");
	            request.getRequestDispatcher("TouristHome.jsp").forward(request, response);
	        } else {
	            request.setAttribute("error", "Email/Password is Incorrect");
	            request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
	        }
	    } else {
	        request.setAttribute("error", "Invalid Role");
	        request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
	    }
	}

}
