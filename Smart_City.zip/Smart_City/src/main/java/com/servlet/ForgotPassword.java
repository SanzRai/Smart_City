package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.controller.TouristController;
import com.controller.TouristControllerImplements;
import com.model.Student;
import com.model.Tourist;

@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		 request.getRequestDispatcher("ForgotPassword.jsp").forward(request, response);
		
	}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        HttpSession session = request.getSession();
        
        String userRole = "";

        try {
            StudentController sc = new StudentControllerImplements();
            TouristController tc = new TouristControllerImplements();
            Student s = sc.getStudentByEmail(email);
            Tourist t = tc.getTouristByEmail(email);

            if (s != null) {
                userRole = "student";
            } else if (t != null) {
                userRole = "tourist";
            } else {
            	session.setAttribute("email", email);
                request.setAttribute("error", "No user found with the provided email.");
                request.getRequestDispatcher("ForgotPassword.jsp").forward(request, response);
                return;
               

            } 
            sendResetLink(request, response, email, userRole); 

        }catch (Exception e) {
                // Handle exception
                e.printStackTrace();
                request.setAttribute("error", "An error occurred. Please try again later.");
                request.getRequestDispatcher("ForgotPassword.jsp").forward(request, response);
            }
        }

            

    private boolean sendResetLink(HttpServletRequest request, HttpServletResponse response, String email, String userRole) throws ServletException {
        
        try {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            session.setAttribute("userRole", userRole);

            request.getRequestDispatcher("ResetPassword.jsp").forward(request, response);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Unable to redirect");
        }
		return false;
    }


}