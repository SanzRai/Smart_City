package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.model.Student;

@WebServlet("/studentTable")
public class StudentTable extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		StudentController sc= new StudentControllerImplements();
		List<Student> studentList = sc.getAllStudents();
		
		 request.setAttribute("studentList", studentList);
		 
		 request.getRequestDispatcher("StudentTable.jsp").forward(request, response);
		
	}

	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String action = request.getParameter("action");
	        if (action != null && action.equals("delete")) {
	            int id = Integer.parseInt(request.getParameter("Id"));
	            StudentController sc = new StudentControllerImplements();
	            boolean deleted = sc.deleteStudent(id);
	            if (deleted) {
	                request.setAttribute("successMessage", "Student deleted successfully");
	            } else {
	                request.setAttribute("errorMessage", "Failed to delete student");
	            }
	        } else {
	            int id = Integer.parseInt(request.getParameter("Id"));
	            String username = request.getParameter("Username");
	            String email = request.getParameter("Email");
	            String phoneNumber = request.getParameter("PhoneNumber");
	            String address = request.getParameter("Address");

	            Student s = new Student();
	            s.setId(id);
	            s.setUsername(username);
	            s.setEmail(email);
	            s.setPhoneNumber(phoneNumber);
	            s.setAddress(address);

	            StudentController sc = new StudentControllerImplements();
	            boolean edited = sc.editStudent(s);
	            if(edited) {
	            List<Student> studentList = sc.getAllStudents();
	            request.setAttribute("studentList", studentList);
	            request.setAttribute("successMessage", "Student edited successfully");
	            }else {
	            	request.setAttribute("errorMessage", "Failed to edit Student data.");
	            }
	        }
	        request.getRequestDispatcher("StudentTable.jsp").forward(request, response);
	        
	    }
	}