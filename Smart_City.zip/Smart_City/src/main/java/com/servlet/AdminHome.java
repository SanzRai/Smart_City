package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.controller.PlaceController;
import com.controller.PlaceControllerImplements;
import com.controller.StudentController;
import com.controller.StudentControllerImplements;
import com.controller.TouristController;
import com.controller.TouristControllerImplements;

/**
 * Servlet implementation class AdminHome
 */
@WebServlet("/AdminHome")
public class AdminHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PlaceController pc = new PlaceControllerImplements();
		StudentController sc = new StudentControllerImplements();
		TouristController tc = new TouristControllerImplements();
		
		int registeredStudentsCount = sc.registeredStudentsCount();
		int registeredTouristsCount = tc.registeredTouristsCount();
		int addedPlacesCount = pc.addedPlacesCount();
		
		request.setAttribute("registeredStudentsCount", registeredStudentsCount);
		request.setAttribute("registeredTouristsCount", registeredTouristsCount);
		request.setAttribute("addedPlacesCount", addedPlacesCount);
		
		request.getRequestDispatcher("AdminHome.jsp").forward(request, response);
		
		 
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
