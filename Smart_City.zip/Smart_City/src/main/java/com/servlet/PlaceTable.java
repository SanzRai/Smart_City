package com.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.controller.PlaceController;
import com.controller.PlaceControllerImplements;
import com.model.Admin;
import com.model.Place;

/**
 * Servlet implementation class Table
 */
@WebServlet("/PlaceTable")
public class PlaceTable extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        
            PlaceController pc = new PlaceControllerImplements();
            List<Place> placeList = pc.getAllData();
             
            request.setAttribute("placeList", placeList);
            request.getRequestDispatcher("PlaceTable.jsp").forward(request, response);
        
        
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         String action = request.getParameter("action");
            

            if (action != null && action.equals("delete")) {
                int id = Integer.parseInt(request.getParameter("id"));
                PlaceController pc = new PlaceControllerImplements();
                boolean deleted = pc.deletePlace(id);
                if (deleted) {
                    List<Place> placeList = pc.getAllData();
                    request.setAttribute("placeList", placeList);
                    request.setAttribute("successMessage", "Place deleted successfully");
                    request.getRequestDispatcher("TouristTable.jsp").forward(request, response);
                } else {
                    request.setAttribute("errorMessage", "Failed to delete place.");
                }
            
            } else { // Edit operation
                int id = Integer.parseInt(request.getParameter("Id"));
                String state = request.getParameter("State");
                String city = request.getParameter("City");
                String category = request.getParameter("Category");
                String name = request.getParameter("Name");
                String image = request.getParameter("ImagePath");
                String fullAddress = request.getParameter("FullAddress");
                String description = request.getParameter("Description");

                Place place = new Place();
                place.setId(id);
                place.setState(state);
                place.setCity(city);
                place.setCategory(category);
                place.setName(name);
                place.setImagePath(image);
                place.setFullAddress(fullAddress);
                place.setDescription(description);
                
                PlaceController pc = new PlaceControllerImplements();
                boolean edited = pc.editPlace(place);
                if (edited) {
                   List<Place> placeList = pc.getAllData();
                   
                   request.setAttribute("placeList", placeList);
                   request.setAttribute("successMessage", "Place data edited successfully.");
                   
                } else {
                	List<Place> placeList = pc.getAllData();
        
                    request.setAttribute("placeList", placeList);
                    request.setAttribute("errorMessage", "Failed to edit place data.");
                    request.getRequestDispatcher("EditPlace.jsp").forward(request, response);
                }
            }
            request.getRequestDispatcher("PlaceTable.jsp").forward(request, response);
            
    }
}
