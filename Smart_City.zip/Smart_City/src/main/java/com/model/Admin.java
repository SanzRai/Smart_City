package com.model;

public class Admin {

	private String Username;
	private String Password;
	
	public boolean authenticate(String Password) {
		return this.Password.equals(Password);
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	
	
	
}
